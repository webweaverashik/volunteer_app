@php
$manifestoItems = [
    ['icon' => '⚖️', 'title' => 'জুলাই অভ্যুত্থানের স্বীকৃতি ও বিচার', 'desc' => 'জুলাই বিপ্লবের শহীদদের যথাযথ স্বীকৃতি এবং অপরাধীদের বিচার নিশ্চিতকরণ।', 'color' => 'red'],
    ['icon' => '📜', 'title' => 'নতুন সংবিধান ও সেকেন্ড রিপাবলিক', 'desc' => 'জনগণের আকাঙ্ক্ষা প্রতিফলিত নতুন সংবিধান প্রণয়ন ও দ্বিতীয় প্রজাতন্ত্র প্রতিষ্ঠা।', 'color' => 'blue'],
    ['icon' => '🏛️', 'title' => 'গণতন্ত্র ও রাষ্ট্রীয় প্রতিষ্ঠানের সংস্কার', 'desc' => 'গণতান্ত্রিক প্রতিষ্ঠানসমূহ শক্তিশালীকরণ ও স্বাধীন নির্বাচন কমিশন গঠন।', 'color' => 'purple'],
    ['icon' => '⚖️', 'title' => 'ন্যায়ভিত্তিক বিচারব্যবস্থা ও আইন সংস্কার', 'desc' => 'স্বাধীন বিচার বিভাগ ও দ্রুত ন্যায়বিচার নিশ্চিতে আইন সংস্কার।', 'color' => 'indigo'],
    ['icon' => '🛡️', 'title' => 'সেবামুখী প্রশাসন ও দুর্নীতি দমন', 'desc' => 'জনগণের সেবায় নিবেদিত স্বচ্ছ ও জবাবদিহিমূলক প্রশাসন গড়ে তোলা।', 'color' => 'green'],
    ['icon' => '🏘️', 'title' => 'ক্ষমতার বিকেন্দ্রীকরণ ও স্থানীয় সরকার', 'desc' => 'স্থানীয় সরকারকে শক্তিশালী করে তৃণমূল পর্যায়ে ক্ষমতা হস্তান্তর।', 'color' => 'teal'],
    ['icon' => '📚', 'title' => 'টেকসই উন্নয়নের জন্য শিক্ষানীতি', 'desc' => 'আধুনিক ও কর্মমুখী শিক্ষাব্যবস্থা গড়ে সুশিক্ষিত জাতি তৈরি।', 'color' => 'yellow'],
    ['icon' => '🏥', 'title' => 'সার্বজনীন স্বাস্থ্য', 'desc' => 'সকল নাগরিকের জন্য সাশ্রয়ী মূল্যে মানসম্মত স্বাস্থ্যসেবা নিশ্চিতকরণ।', 'color' => 'pink'],
    ['icon' => '🙏', 'title' => 'ধর্ম, সম্প্রদায় ও জাতিসত্ত্বার মর্যাদা', 'desc' => 'সকল ধর্ম ও জাতিসত্ত্বার সমান অধিকার ও মর্যাদা রক্ষা।', 'color' => 'orange'],
    ['icon' => '💹', 'title' => 'কল্যাণমুখী অর্থনীতি', 'desc' => 'সামাজিক সুরক্ষা ও অর্থনৈতিক সমতা নিশ্চিতে কল্যাণমূলক অর্থনৈতিক নীতি।', 'color' => 'emerald', 'hidden' => true],
    ['icon' => '👮', 'title' => 'জনবান্ধব পুলিশ', 'desc' => 'জনগণের সেবায় নিবেদিত আধুনিক ও জবাবদিহিমূলক পুলিশ বাহিনী।', 'color' => 'slate', 'hidden' => true],
    ['icon' => '👩‍💼', 'title' => 'নারীর নিরাপত্তা, অধিকার ও ক্ষমতায়ন', 'desc' => 'নারীদের সমান অধিকার, নিরাপত্তা ও সকল ক্ষেত্রে ক্ষমতায়ন।', 'color' => 'rose', 'hidden' => true],
    ['icon' => '💻', 'title' => 'গবেষণা, উদ্ভাবন ও তথ্যপ্রযুক্তি বিপ্লব', 'desc' => 'বিজ্ঞান ও প্রযুক্তি খাতে বিনিয়োগ বৃদ্ধি ও ডিজিটাল বাংলাদেশ গঠন।', 'color' => 'cyan', 'hidden' => true],
    ['icon' => '🎯', 'title' => 'তারুণ্য ও কর্মসংস্থান', 'desc' => 'যুবসমাজের জন্য কর্মসংস্থান সৃষ্টি ও উদ্যোক্তা উন্নয়ন কার্যক্রম।', 'color' => 'violet', 'hidden' => true],
    ['icon' => '🏭', 'title' => 'বহুমুখী বাণিজ্য ও শিল্পায়ন নীতি', 'desc' => 'বৈচিত্র্যময় শিল্প ও রপ্তানিমুখী অর্থনীতি গড়ে তোলা।', 'color' => 'amber', 'hidden' => true],
    ['icon' => '🌾', 'title' => 'টেকসই কৃষি ও খাদ্য সার্বভৌমত্ব', 'desc' => 'কৃষকদের ন্যায্য মূল্য ও আধুনিক কৃষি প্রযুক্তির মাধ্যমে খাদ্য নিরাপত্তা।', 'color' => 'lime', 'hidden' => true],
    ['icon' => '📰', 'title' => 'স্বাধীন গণমাধ্যম ও শক্তিশালী নাগরিক সমাজ', 'desc' => 'মুক্ত সংবাদ মাধ্যম ও সক্রিয় নাগরিক সমাজ গড়ে তোলা।', 'color' => 'sky', 'hidden' => true],
    ['icon' => '✊', 'title' => 'শ্রমিক-কৃষকের অধিকার', 'desc' => 'শ্রমিক ও কৃষকদের ন্যায্য মজুরি, নিরাপত্তা ও অধিকার সুরক্ষা।', 'color' => 'stone', 'hidden' => true],
    ['icon' => '💎', 'title' => 'জাতীয় সম্পদ ব্যবস্থাপনা', 'desc' => 'প্রাকৃতিক সম্পদের সুষ্ঠু ব্যবস্থাপনা ও জাতীয় স্বার্থ রক্ষা।', 'color' => 'zinc', 'hidden' => true],
    ['icon' => '🏗️', 'title' => 'নগরায়ন, পরিবহন ও আবাসন পরিকল্পনা', 'desc' => 'পরিকল্পিত নগরায়ন ও সকলের জন্য সাশ্রয়ী আবাসন নিশ্চিতকরণ।', 'color' => 'neutral', 'hidden' => true],
    ['icon' => '🌊', 'title' => 'জলবায়ু সহনশীলতা ও নদী-সমুদ্র রক্ষা', 'desc' => 'পরিবেশ সংরক্ষণ, নদী দূষণ রোধ ও জলবায়ু পরিবর্তন মোকাবেলা।', 'color' => 'blue', 'hidden' => true],
    ['icon' => '✈️', 'title' => 'প্রবাসী বাংলাদেশির মর্যাদা ও অধিকার', 'desc' => 'প্রবাসীদের অধিকার সুরক্ষা ও তাদের বিনিয়োগে সহায়তা প্রদান।', 'color' => 'sky', 'hidden' => true],
    ['icon' => '🌐', 'title' => 'বাংলাদেশপন্থী পররাষ্ট্রনীতি', 'desc' => 'জাতীয় স্বার্থ রক্ষায় স্বাধীন ও ভারসাম্যপূর্ণ পররাষ্ট্রনীতি।', 'color' => 'green', 'hidden' => true],
    ['icon' => '🛡️', 'title' => 'জাতীয় প্রতিরক্ষা কৌশল', 'desc' => 'দেশের সার্বভৌমত্ব ও নিরাপত্তা রক্ষায় আধুনিক প্রতিরক্ষা ব্যবস্থা।', 'color' => 'red', 'hidden' => true],
];
@endphp

<section class="py-16 bg-white">
    <div class="max-w-6xl mx-auto px-4">
        <div class="text-center mb-12">
            <div class="inline-flex items-center gap-2 bg-red-100 text-red-700 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                জুলাই বিপ্লবের চেতনায়
            </div>
            <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">নতুন বাংলাদেশের ইশতেহার</h2>
            <div class="w-24 h-1 bg-green-500 mx-auto mb-4"></div>
            <p class="text-gray-600 max-w-2xl mx-auto">সিলেট-৩ আসনে একটি উন্নত, সমৃদ্ধ ও ন্যায়ভিত্তিক নতুন বাংলাদেশ গঠনে আমাদের ২৪ দফা প্রতিশ্রুতি</p>
        </div>

        <div id="manifestoGrid" class="manifesto-grid gap-6">
            @foreach($manifestoItems as $index => $item)
            <div class="manifesto-item {{ isset($item['hidden']) && $item['hidden'] ? 'hidden-item' : '' }} text-center p-6 rounded-2xl bg-gradient-to-br from-{{ $item['color'] }}-50 to-{{ $item['color'] }}-100 card-shadow hover:transform hover:scale-105 transition">
                <div class="text-5xl mb-4">{{ $item['icon'] }}</div>
                <h3 class="text-xl font-bold text-gray-800 mb-3">{{ $item['title'] }}</h3>
                <p class="text-gray-600 text-sm">{{ $item['desc'] }}</p>
            </div>
            @endforeach
        </div>

        <div class="mt-10 text-center">
            <button id="toggleManifesto" class="expand-btn inline-flex items-center gap-3 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition transform hover:scale-105 shadow-lg">
                <span id="toggleText">সবগুলো দেখুন</span>
                <span id="toggleCount" class="bg-white/20 px-3 py-1 rounded-full text-sm">+১৫</span>
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
        </div>
    </div>
</section>
