"use strict";

var KTUsersList = function () {
      // Define shared variables
      var table;
      var datatable;

      // Private functions
      var initDatatable = function () {
            // Init datatable --- more info on datatables: https://datatables.net/manual/
            datatable = $(table).DataTable({
                  "info": true,
                  'order': [],
                  "lengthMenu": [10, 25, 50, 100],
                  "pageLength": 10,
                  "lengthChange": true,
                  "autoWidth": false,  // Disable auto width
                  'columnDefs': [{
                        // orderable: false, targets: [5, 6]
                  }]
            });

            // Re-init functions on every table re-draw -- more info: https://datatables.net/reference/event/draw
            datatable.on('draw', function () {

            });
      }

      // Search Datatable --- official docs reference: https://datatables.net/reference/api/search()
      var handleSearch = function () {
            const filterSearch = document.querySelector('[data-kt-user-table-filter="search"]');
            filterSearch.addEventListener('keyup', function (e) {
                  datatable.search(e.target.value).draw();
            });
      }
      // Toggle activation
      var handleToggleActivation = function () {
            const toggleInputs = document.querySelectorAll('.toggle-active');

            toggleInputs.forEach(input => {
                  input.addEventListener('change', function () {
                        const userId = this.value;
                        const isActive = this.checked ? 1 : 0;
                        const row = this.closest('tr'); // Get the parent <tr> element

                        console.log('User ID:', userId);

                        let url = routeToggleActive.replace(':id', userId);  // Replace ':id' with actual student ID


                        fetch(url, {
                              method: 'POST',
                              headers: {
                                    'Content-Type': 'application/json',
                                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute("content"),
                              },
                              body: JSON.stringify({
                                    user_id: userId,
                                    is_active: isActive
                              })
                        })
                              .then(response => {
                                    if (!response.ok) {
                                          throw new Error('Network response was not ok');
                                    }
                                    return response.json();
                              })
                              .then(data => {
                                    if (data.success) {
                                          toastr.success(data.message);
                                    } else {
                                          toastr.error(data.message);
                                    }
                              })
                              .catch(error => {
                                    console.error('Error:', error);
                                    toastr.error('Error occurred while toggling farm status');
                              });
                  });
            });
      };

      return {
            // Public functions  
            init: function () {
                  table = document.getElementById('kt_table_users');

                  if (!table) {
                        return;
                  }

                  initDatatable();
                  handleSearch();
                  handleToggleActivation();
            }
      }
}();

var KTUsersEditPassword = function () {
      // Shared variables
      const element = document.getElementById('kt_modal_edit_password');
      const form = element.querySelector('#kt_modal_edit_password_form');
      const modal = new bootstrap.Modal(element);

      let userId = null;
      let validator = null; // Declare validator globally

      // Init add schedule modal
      var initEditPassword = () => {
            const passwordInput = document.getElementById('teacherPasswordNew');
            const strengthText = document.getElementById('password-strength-text');
            const strengthBar = document.getElementById('password-strength-bar');

            // Cancel button handler
            const cancelButton = element.querySelector('[data-kt-edit-password-modal-action="cancel"]');
            cancelButton.addEventListener('click', e => {
                  e.preventDefault();

                  form.reset(); // Reset form			
                  modal.hide();

                  // Reset strength meter
                  if (strengthText) strengthText.textContent = '';
                  if (strengthBar) {
                        strengthBar.className = 'progress-bar';
                        strengthBar.style.width = '0%';
                  }
            });

            // Close button handler
            const closeButton = element.querySelector('[data-kt-edit-password-modal-action="close"]');
            closeButton.addEventListener('click', e => {
                  e.preventDefault();

                  form.reset(); // Reset form			
                  modal.hide();

                  // Reset strength meter
                  if (strengthText) strengthText.textContent = '';
                  if (strengthBar) {
                        strengthBar.className = 'progress-bar';
                        strengthBar.style.width = '0%';
                  }
            });


            // AJAX loading password modal data
            document.addEventListener('click', function (e) {
                  // Handle password toggle
                  const toggleBtn = e.target.closest('.toggle-password');
                  if (toggleBtn) {
                        const inputId = toggleBtn.getAttribute('data-target');
                        const input = document.getElementById(inputId);
                        const icon = toggleBtn.querySelector('i');

                        if (input) {
                              const isPassword = input.type === 'password';
                              input.type = isPassword ? 'text' : 'password';

                              if (icon) {
                                    icon.classList.toggle('ki-eye');
                                    icon.classList.toggle('ki-eye-slash');
                              }
                        }
                        return; // Prevent falling through to next case
                  }

                  // Handle edit password modal button
                  const changePasswordBtn = e.target.closest('.change-password-btn');
                  if (changePasswordBtn) {
                        userId = changePasswordBtn.getAttribute('data-user-id');
                        console.log('User ID:', userId);

                        const userName = changePasswordBtn.getAttribute('data-user-name');

                        const userIdInput = document.getElementById('user_id_input');
                        const modalTitle = document.getElementById('kt_modal_edit_password_title');

                        if (userIdInput) userIdInput.value = userId;
                        if (modalTitle) modalTitle.textContent = `জনাব ${userName} এর পাসওয়ার্ড পরিবর্তন`;
                  }
            });

            // Live strength meter
            if (passwordInput) {
                  passwordInput.addEventListener('input', function () {
                        const value = passwordInput.value;
                        let score = 0;

                        if (value.length >= 8) score++;
                        if (/[A-Z]/.test(value)) score++;
                        if (/[a-z]/.test(value)) score++;
                        if (/\d/.test(value)) score++;
                        if (/[^A-Za-z0-9]/.test(value)) score++;

                        let strength = '';
                        let barColor = '';
                        let width = score * 20;

                        switch (score) {
                              case 0:
                              case 1:
                                    strength = 'Very Weak';
                                    barColor = 'bg-danger';
                                    break;
                              case 2:
                                    strength = 'Weak';
                                    barColor = 'bg-warning';
                                    break;
                              case 3:
                                    strength = 'Moderate';
                                    barColor = 'bg-info';
                                    break;
                              case 4:
                                    strength = 'Strong';
                                    barColor = 'bg-primary';
                                    break;
                              case 5:
                                    strength = 'Very Strong';
                                    barColor = 'bg-success';
                                    break;
                        }

                        strengthText.textContent = strength;
                        strengthBar.className = `progress-bar ${barColor}`;
                        strengthBar.style.width = `${width}%`;
                  });
            }
      }


      // Form validation
      var initFormValidation = function () {
            if (!form) return;

            validator = FormValidation.formValidation(
                  form,
                  {
                        fields: {
                              'new_password': {
                                    validators: {
                                          notEmpty: {
                                                message: 'পাসওয়ার্ড প্রয়োজন'
                                          },
                                          stringLength: {
                                                min: 8,
                                                message: '* কমপক্ষে ৮ ডিজিট হতে হবে'
                                          },
                                          regexp: {
                                                regexp: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{8,}$/,
                                                message: '* Must contain uppercase, lowercase, number, and special character'
                                          }
                                    }
                              },
                        },
                        plugins: {
                              trigger: new FormValidation.plugins.Trigger(),
                              bootstrap: new FormValidation.plugins.Bootstrap5({
                                    rowSelector: '.fv-row',
                                    eleInvalidClass: '',
                                    eleValidClass: ''
                              })
                        }
                  }
            );

            const submitButton = element.querySelector('[data-kt-edit-password-modal-action="submit"]');

            if (submitButton && validator) {
                  submitButton.addEventListener('click', function (e) {
                        e.preventDefault(); // Prevent default button behavior

                        validator.validate().then(function (status) {
                              if (status === 'Valid') {
                                    // Show loading indicator
                                    submitButton.setAttribute('data-kt-indicator', 'on');
                                    submitButton.disabled = true;

                                    const formData = new FormData(form);
                                    formData.append('_token', document.querySelector('meta[name="csrf-token"]').content);
                                    formData.append('_method', 'PUT');

                                    console.log('Updating password for User ID:', userId);
                                    fetch(`/admin/users/${userId}/password`, {
                                          method: 'POST',
                                          body: formData,
                                          headers: {
                                                'Accept': 'application/json',
                                                'X-Requested-With': 'XMLHttpRequest'
                                          }
                                    })
                                          .then(response => {
                                                if (!response.ok) {
                                                      return response.json().then(errorData => {
                                                            // Show error from Laravel if available
                                                            throw new Error(errorData.message || 'Network response was not ok');
                                                      });
                                                }
                                                return response.json();
                                          })
                                          .then(data => {
                                                submitButton.removeAttribute('data-kt-indicator');
                                                submitButton.disabled = false;

                                                if (data.success) {
                                                      toastr.success(data.message || 'Password updated successfully');
                                                      modal.hide();
                                                      setTimeout(() => {
                                                            window.location.reload();
                                                      }, 1500); // 1000ms = 1 second delay
                                                } else {
                                                      throw new Error(data.message || 'Password Update failed');
                                                }
                                          })
                                          .catch(error => {
                                                submitButton.removeAttribute('data-kt-indicator');
                                                submitButton.disabled = false;
                                                toastr.error(error.message || 'Failed to update user');
                                                console.error('Error:', error);
                                          });
                              } else {
                                    toastr.warning('Please fill all required fields');
                              }
                        });
                  });
            }
      };

      return {
            // Public functions
            init: function () {
                  initEditPassword();
                  initFormValidation();
            }
      };
}();

var KTEditUser = function () {
      // Shared variables
      const element = document.getElementById('kt_modal_edit_user');

      // Early return if element doesn't exist
      if (!element) {
            console.error('Modal element not found');
            return {
                  init: function () { }
            };
      }

      const form = element.querySelector('#kt_modal_edit_user_form');
      const modal = bootstrap.Modal.getOrCreateInstance(element);

      let userId = null; // Declare globally

      // Init edit institution modal
      var iniEditUser = () => {
            // Cancel button handler
            const cancelButton = element.querySelector('[data-kt-edit-users-modal-action="cancel"]');
            if (cancelButton) {
                  cancelButton.addEventListener('click', e => {
                        e.preventDefault();
                        if (form) form.reset();
                        modal.hide();
                  });
            }

            // Close button handler
            const closeButton = element.querySelector('[data-kt-edit-users-modal-action="close"]');
            if (closeButton) {
                  closeButton.addEventListener('click', e => {
                        e.preventDefault();
                        if (form) form.reset();
                        modal.hide();
                  });
            }

            // Delegated click for edit buttons
            document.addEventListener("click", function (e) {
                  const button = e.target.closest("[data-bs-target='#kt_modal_edit_user']");
                  if (!button) return;

                  userId = button.getAttribute("data-user-id");
                  if (!userId) return;

                  // Clear form
                  if (form) form.reset();

                  fetch(`/admin/users/${userId}`)
                        .then(response => {
                              if (!response.ok) {
                                    return response.json().then(errorData => {
                                          throw new Error(errorData.message || 'Network response was not ok');
                                    });
                              }
                              return response.json();
                        })
                        .then(data => {
                              if (data.success && data.data) {
                                    const user = data.data;

                                    // Set values
                                    const setValue = (selector, value) => {
                                          const el = document.querySelector(selector);
                                          if (el) el.value = value;
                                    };

                                    setValue("input[name='user_name_edit']", user.name);
                                    setValue("input[name='email_edit']", user.email);

                                    modal.show();
                              } else {
                                    throw new Error(data.message || 'Invalid response data');
                              }
                        })
                        .catch(error => {
                              console.error("Error:", error);
                              toastr.error(error.message || "Failed to load institution details");
                        });
            });
      };


      // Form validation
      var initValidation = function () {
            if (!form) return;

            var validator = FormValidation.formValidation(
                  form,
                  {
                        fields: {
                              'user_name_edit': {
                                    validators: {
                                          notEmpty: {
                                                message: 'নাম উল্লেখ প্রয়োজন'
                                          }
                                    }
                              },
                              'email_edit': {
                                    validators: {
                                          notEmpty: {
                                                message: 'লগিন করার জন্য ইউজারের ইমেইল প্রয়োজন'
                                          },
                                          emailAddress: {
                                                message: 'অনুগ্রহ করে সঠিক ইমেইল দিন',
                                          },
                                    }
                              },
                        },
                        plugins: {
                              trigger: new FormValidation.plugins.Trigger(),
                              bootstrap: new FormValidation.plugins.Bootstrap5({
                                    rowSelector: '.fv-row',
                                    eleInvalidClass: '',
                                    eleValidClass: ''
                              })
                        }
                  }
            );

            const submitButton = element.querySelector('[data-kt-edit-users-modal-action="submit"]');
            if (submitButton && validator) {
                  submitButton.addEventListener('click', function (e) {
                        e.preventDefault();

                        validator.validate().then(function (status) {
                              if (status == 'Valid') {
                                    // Show loading indication
                                    submitButton.setAttribute('data-kt-indicator', 'on');
                                    submitButton.disabled = true;

                                    // Prepare form data
                                    const formData = new FormData(form);

                                    // Add CSRF token for Laravel
                                    formData.append('_token', document.querySelector('meta[name="csrf-token"]').content);
                                    formData.append('_method', 'PUT'); // For Laravel resource route

                                    // Submit via AJAX
                                    fetch(`/admin/users/${userId}`, {
                                          method: 'POST', // Laravel expects POST for PUT routes
                                          body: formData,
                                          headers: {
                                                'Accept': 'application/json',
                                                'X-Requested-With': 'XMLHttpRequest'
                                          }
                                    })
                                          .then(response => {
                                                if (!response.ok) throw new Error('Network response was not ok');
                                                return response.json();
                                          })
                                          .then(data => {
                                                submitButton.removeAttribute('data-kt-indicator');
                                                submitButton.disabled = false;

                                                if (data.success) {
                                                      toastr.success(data.message || 'User updated successfully');
                                                      modal.hide();

                                                      // Reload the page
                                                      window.location.reload();
                                                } else {
                                                      throw new Error(data.message || 'Update failed');
                                                }
                                          })
                                          .catch(error => {
                                                submitButton.removeAttribute('data-kt-indicator');
                                                submitButton.disabled = false;
                                                toastr.error(error.message || 'Failed to update user');
                                                console.error('Error:', error);
                                          });
                              } else {
                                    toastr.warning('Please fill all required fields correctly');
                              }
                        });
                  });
            }
      }

      return {
            init: function () {
                  iniEditUser();
                  initValidation();
            }
      };
}();

var KTAddUser = function () {
      // Shared variables
      const element = document.getElementById('kt_modal_add_user');

      // Early return if element doesn't exist
      if (!element) {
            console.error('Modal element not found');
            return {
                  init: function () { }
            };
      }

      const form = element.querySelector('#kt_modal_add_user_form');
      const modal = bootstrap.Modal.getOrCreateInstance(element);

      // Init edit institution modal
      var initAddUser = () => {
            // Cancel button handler
            const cancelButton = element.querySelector('[data-kt-add-users-modal-action="cancel"]');
            if (cancelButton) {
                  cancelButton.addEventListener('click', e => {
                        e.preventDefault();
                        if (form) form.reset();
                        modal.hide();
                  });
            }

            // Close button handler
            const closeButton = element.querySelector('[data-kt-add-users-modal-action="close"]');
            if (closeButton) {
                  closeButton.addEventListener('click', e => {
                        e.preventDefault();
                        if (form) form.reset();
                        modal.hide();
                  });
            }
      }

      // Form validation
      var initValidation = function () {
            if (!form) return;

            var validator = FormValidation.formValidation(
                  form,
                  {
                        fields: {
                              'user_name_add': {
                                    validators: {
                                          notEmpty: {
                                                message: 'নাম উল্লেখ প্রয়োজন'
                                          }
                                    }
                              },
                              'email_add': {
                                    validators: {
                                          notEmpty: {
                                                message: 'লগিন করার জন্য ইউজারের ইমেইল প্রয়োজন'
                                          },
                                          emailAddress: {
                                                message: 'অনুগ্রহ করে সঠিক ইমেইল দিন',
                                          },
                                    }
                              },
                        },
                        plugins: {
                              trigger: new FormValidation.plugins.Trigger(),
                              bootstrap: new FormValidation.plugins.Bootstrap5({
                                    rowSelector: '.fv-row',
                                    eleInvalidClass: '',
                                    eleValidClass: ''
                              })
                        }
                  }
            );

            const submitButton = element.querySelector('[data-kt-add-users-modal-action="submit"]');
            if (submitButton && validator) {
                  submitButton.addEventListener('click', function (e) {
                        e.preventDefault();

                        validator.validate().then(function (status) {
                              if (status == 'Valid') {
                                    // Show loading indication
                                    submitButton.setAttribute('data-kt-indicator', 'on');
                                    submitButton.disabled = true;

                                    // Prepare form data
                                    const formData = new FormData(form);

                                    // Add CSRF token for Laravel
                                    formData.append('_token', document.querySelector('meta[name="csrf-token"]').content);

                                    // Submit via AJAX
                                    fetch(`/admin/users`, {
                                          method: 'POST', // Laravel expects POST for PUT routes
                                          body: formData,
                                          headers: {
                                                'Accept': 'application/json',
                                                'X-Requested-With': 'XMLHttpRequest'
                                          }
                                    })
                                          .then(response => {
                                                if (!response.ok) {
                                                      return response.json().then(errorData => {
                                                            // Show error from Laravel if available
                                                            throw new Error(errorData.message || 'Network response was not ok');
                                                      });
                                                }
                                                return response.json();
                                          })
                                          .then(data => {
                                                submitButton.removeAttribute('data-kt-indicator');
                                                submitButton.disabled = false;

                                                if (data.success) {
                                                      toastr.success(data.message || 'User added successfully');
                                                      modal.hide();

                                                      // Reload the page
                                                      window.location.reload();
                                                } else {
                                                      throw new Error(data.message || 'Update failed');
                                                }
                                          })
                                          .catch(error => {
                                                submitButton.removeAttribute('data-kt-indicator');
                                                submitButton.disabled = false;
                                                toastr.error(error.message || 'Failed to update User');
                                                console.error('Error:', error);
                                          });
                              } else {
                                    toastr.warning('Please fill all required fields correctly');
                              }
                        });
                  });
            }
      }

      return {
            init: function () {
                  initAddUser();
                  initValidation();
            }
      };
}();

// On document ready
KTUtil.onDOMContentLoaded(function () {
      KTUsersList.init();
      KTUsersEditPassword.init();
      KTAddUser.init();
      KTEditUser.init();
});